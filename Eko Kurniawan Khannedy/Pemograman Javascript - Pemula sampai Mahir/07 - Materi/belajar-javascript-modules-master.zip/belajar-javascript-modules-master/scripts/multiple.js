const company = "Programmer Zaman Now";

function sum(first, second) {
    return first + second;
}

class Company {

}

export {company, sum, Company}
