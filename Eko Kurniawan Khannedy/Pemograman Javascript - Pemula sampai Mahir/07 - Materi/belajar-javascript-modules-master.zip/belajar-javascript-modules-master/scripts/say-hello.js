export default function (name) {
    console.info(`Hello ${name}, from default function`);
}
