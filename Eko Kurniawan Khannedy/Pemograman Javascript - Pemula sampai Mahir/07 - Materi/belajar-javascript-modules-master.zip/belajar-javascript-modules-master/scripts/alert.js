export function alertHello(name){
    alert(`Hello ${name}`);
}
