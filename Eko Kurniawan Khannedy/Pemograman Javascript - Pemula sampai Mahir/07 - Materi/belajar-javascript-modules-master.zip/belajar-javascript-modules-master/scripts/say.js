export function sayHello(name) {
    console.info(`Hello ${name}`);
}

export function sayGoodBye(name) {
    console.info(`Good Bye ${name}`);
}

export const name = "Eko";
