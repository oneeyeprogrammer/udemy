function sayHello(name) {
    console.info(`Hello ${name}`);
}

function sayGoodBye(name) {
    console.info(`Good Bye ${name}`);
}

const name = "Eko";
