export const title = "Programmer Zaman Now";

const content = "Belajar JavaScript Module";

const author = "Eko Kurniawan Khannedy";

export {content};
export default author;
