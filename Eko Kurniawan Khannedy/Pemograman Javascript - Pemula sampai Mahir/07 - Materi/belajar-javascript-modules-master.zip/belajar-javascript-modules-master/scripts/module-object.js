export const firstName = "Eko";
export const middleName = "Kurniawan";
export const lastName = "Khannedy";

export function hello(){
    console.info("Hello from Eko");
}

export class Person {

    constructor() {
        this.name = "Eko";
    }
}
