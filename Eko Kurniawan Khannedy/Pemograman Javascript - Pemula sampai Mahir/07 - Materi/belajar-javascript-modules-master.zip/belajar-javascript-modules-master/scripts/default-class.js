export default class {

    constructor(name) {
        this.name = name;
    }

    sayHi(){
        console.info(`Hi, my name is ${this.name}`);
    }
}
