export {Person} from "./class.js";
export {sayHello, sayGoodBye} from "./say.js";
export {sum} from "./multiple.js";
