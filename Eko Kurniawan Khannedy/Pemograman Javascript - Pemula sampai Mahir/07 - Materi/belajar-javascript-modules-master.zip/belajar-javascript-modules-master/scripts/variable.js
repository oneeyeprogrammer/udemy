
export const name = "Eko Kurniawan Khannedy";
